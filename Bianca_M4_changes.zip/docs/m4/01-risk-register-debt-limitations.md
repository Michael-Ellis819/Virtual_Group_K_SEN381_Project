# Final Risk Register, Technical Debt and Known Limitations

Owner: Bianca Grobler (600537). Status: **DRAFT for team confirmation**. Baseline described: the repository snapshot supplied (`Virtual_Group_K_SEN381_Project-main`) plus Bianca's M4 lifecycle code. **Final commit hash: [NEEDS: team to insert].**

This continues the existing register (R-001 to R-045 from PED v3.0, and M3-R01 to M3-R05 from PED §7.4). It is not a new register. Risk wording is unchanged; only the final status, the effectiveness of the mitigation and the evidence are added.

## How to read the columns

- **Final status:** *Closed – not realised* (did not happen and no longer applies), *Mitigated – residual risk* (controls work for what exists; something remains), *Realised* (it happened), *Open – carried forward* (still a problem), *Not exercised – carried forward* (the project never reached a point where this could be tested, so there is no evidence either way).
- **Mitigation effectiveness:** *Effective*, *Partly effective*, *Ineffective*, or *Not evidenced*. "Not evidenced" is used whenever the repository holds no proof either way. It is not a claim that the mitigation failed.
- Items marked "owner to confirm" depend on records that are not in the repository (effort logs, hosting, pricing). They must not be closed on assertion.

## Summary

| Final status | Count (of 45 R-items) |
| --- | --- |
| Closed – not realised | 5 |
| Mitigated – residual risk | 12 |
| Realised | 6 |
| Open – carried forward | 15 |
| Not exercised – carried forward | 7 |

Mitigation effectiveness across the 45: Effective 11, Partly effective 11, Ineffective 3, Not evidenced 20.

The pattern matters more than the counts. Risks that sit inside the part of the system that was built (access control, privacy of notes, error handling, business-logic independence) were mitigated and have passing checks. Risks that depend on parts that were never built or deployed (hosting, HTTPS, recovery, performance, ownership persistence) have no evidence at all. Twenty of the 45 mitigations are "not evidenced" for that reason.

## Final register

| ID | Risk | Owner | Initial priority | Final status | Mitigation effectiveness | Evidence and reason |
| --- | --- | --- | --- | --- | --- | --- |
| R-001 | Schedule slip due to unfamiliarity with the chosen technology stack | Bianca | High | Realised | Partly effective | Scope shortfall exists (no sign-in, creation, list or write routes in the final build; see scope table). Persistence only arrived 8–12 Oct. Whether stack unfamiliarity or capacity was the cause needs the effort logs; the spike (PED 5.5.12) did not prevent the slip. |
| R-002 | Free-tier hosting/database limits exceeded during dev, testing or demo | Cameron | Medium | Not exercised – carried forward | Not evidenced | No hosted environment evidence in the repo. Cameron/Michael to confirm. |
| R-003 | Uncontrolled scope creep from informal "quick add" requests | Michael | High | Closed – not realised | Effective | RTM change column reads 'requirement/AC unchanged' for all 27 requirements; no change request in the repo. Scope fell short by omission, not by creep. |
| R-004 | Sensitive requester data exposed due to coarse role-based access control | Team | High | Mitigated – residual risk | Effective | Deny-by-default central policy; S03–S12, H03/H07/H09/H11 and DB access checks pass. Covers the one protected read operation only; no write route exists. |
| R-005 | Secrets/credentials accidentally committed to GitHub | Michael | High | Mitigated – residual risk | Effective | No real credentials found in the repo (scan of .cs, .json, .yml, .csproj, .md). CI uses a throwaway 'testpassword' for a service container only. DatabaseTests reads user secrets/environment. *.env is git-ignored. |
| R-006 | Uneven team contribution causes one member to fall behind before a deadline | Team | Medium | Open – carried forward | Not evidenced | Needs effort logs and GitHub contribution history, which are outside the zip. Do not close without them. |
| R-007 | AI-assisted output contains unverified or incorrect claims | Whoever used the AI tool | Medium | Mitigated – residual risk | Partly effective | Register exists, but entries disagree: docs/ai-usage.md says Cameron used OpenAI Codex, PED §12 says ChatGPT. Register must be reconciled (see AI register). |
| R-008 | Layer boundaries in the chosen layered architecture are not respected under schedule pressure (e.g. UI calling the database directly), undermining ADR-M2-01. | Bianca | Medium | Mitigated – residual risk | Partly effective | Controller → service → IRequestReader holds for reads. EfRequestStatusWriter is a concrete class with no interface and is not registered in Composition.cs, so the write path is unreachable from the app. |
| R-009 | Business logic layer becomes tightly coupled to whichever ORM/framework is chosen in §5.5, undermining the testability ASR (NFR-009). | Bianca | Medium | Closed – not realised | Effective | The Lifecycle namespace compiled and ran its 44 checks with no EF Core, ASP.NET or NuGet references at all. Business rules are independent of persistence. |
| R-010 | Architecture is over-engineered beyond pilot scale (e.g. premature service splitting), wasting schedule the team cannot recover. | Bianca | Medium | Closed – not realised | Partly effective | State pattern cost four small files and six tiny classes; it did not grow. Whether it earned its cost is a judgement, see the ADR-M2-02 reflection. |
| R-011 | StatusTransitionService (ADR-M2-02) is bypassed by some code paths, allowing invalid FR-010 transitions to occur. | Bianca | High | Mitigated – residual risk | Partly effective | StatusTransitionService now exists and ValidatedStatusChange can only be created by it. AR01 fails the build if new code assigns a status. But no production code path calls the service yet, and EfRequestStatusWriter still accepts raw strings. Not closed. |
| R-012 | Architecture diagrams become outdated as implementation evolves, misleading the M3/M4 engineering defence. | Bianca | Medium | Open – carried forward | Not evidenced | docs/design.md still shows only the M2 read slice. Update before the defence. |
| R-013 | The coarse three-role access model (M1 R-004) is enforced inconsistently across layers, creating a privilege-escalation path. | Bianca | High | Mitigated – residual risk | Effective | One central policy; service re-checks for non-HTTP callers; tests S01–S12. |
| R-014 | The relational schema does not adequately model request history (FR-015 and NFR-003), forcing a costly migration later. | Michael | High | Realised | Partly effective | History table covers status changes only (TD-M3-02). Ownership, priority, due-date and note changes are not recorded, so FR-015 is partial. Migrations absorbed the change cheaply (three migrations). |
| R-015 | Concurrent assignment attempts (AC-FR-009-2) are not protected by a database-level constraint, allowing two owners on one request. | Michael | High | Open – carried forward | Ineffective | Schema has no owner column, so a database constraint against two owners cannot exist yet. OwnershipRule rejects a second owner in memory, and the Version token protects status updates, but simultaneous claims are not verified. |
| R-016 | Free-tier database connection limits are exceeded during NFR-002 concurrency testing. | Michael | Medium | Not exercised – carried forward | Not evidenced | No concurrency or load test run. |
| R-017 | The data model does not clearly separate requester-visible feedback from internal staff notes (FR-011/AC-FR-011-2), risking accidental disclosure. | Michael | High | Mitigated – residual risk | Effective | IsRequesterVisible flag plus DTO projection. S02, H05, H08 and DB checks for note visibility pass. |
| R-018 | The chosen free-tier persistence option cannot meet the NFR-007 backup/recovery targets (24h RPO / 4h RTO). | Michael | High | Open – carried forward | Not evidenced | No backup or restore test (TD-M3-04). NFR-007 unmet. |
| R-019 | The fixed category list (7 categories) is hard-coded in more than one place instead of a single controlled reference table, causing drift. | Michael | Medium | Realised | Ineffective | CategoryId is a free-text string; there is no category table or validation. FR-002 is not met. |
| R-020 | A selected framework or library reaches end-of-support or ships a breaking major release during the project. | Michael | Low | Realised | Ineffective | The project targets net8.0. Microsoft ends .NET 8 support on 10 November 2026. No upgrade was done; carry to future work (target a supported LTS). |
| R-021 | The team's limited prior experience with the selected backend framework increases defect rate under schedule pressure (extends M1 R-001). | Michael | Medium | Open – carried forward | Not evidenced | Same evidence gap as R-001. |
| R-022 | Free-tier hosting cold-start latency causes NFR-002 (3-second) tests to fail despite correct application code. | Michael | Medium | Not exercised – carried forward | Not evidenced | No hosted instance, so cold start was never measured. |
| R-023 | A dependency introduces a known vulnerability flagged by automated scanning once available. | Michael | High | Open – carried forward | Not evidenced | No vulnerability scan evidence. Run 'dotnet list package --vulnerable --include-transitive' locally and record it (EF Core and Npgsql are pinned at 8.0.11). |
| R-024 | Licensing terms of a selected library or service conflict with the team's free/educational-use assumption (A-03/A-04). | Michael | Medium | Open – carried forward | Not evidenced | Owner to confirm licences. EF Core and ASP.NET Core are MIT; check Npgsql's licence text before stating it. |
| R-025 | Vendor lock-in to a specific free-tier platform makes migration after the course costly. | Michael | Low | Not exercised – carried forward | Not evidenced | No platform chosen in practice. |
| R-026 | The second design-pattern decision (§5.6, Cameron) overlaps with the State-pattern responsibility boundary from ADR-M2-02, duplicating logic. | Cameron / Bianca | Medium | Closed – not realised | Effective | The transition service takes no identity or role and the access policy takes no status, so there is no overlap. Checked by reading both. |
| R-027 | The API/integration boundary (§5.7) accepts invalid status values directly instead of delegating to StatusTransitionService. | Cameron | High | Open – carried forward | Not evidenced | No write endpoint exists (H14), so nothing accepts invalid statuses today. When one is built it must call IStatusTransitionService. Cameron to confirm in the PR. |
| R-028 | A design-pattern decision is documented in an ADR but has no corresponding implementation evidence, violating the M2 evidence-completeness rule. | Cameron / Bianca | High | Mitigated – residual risk | Partly effective | ADR-M2-02 now has code and 44 checks. ADR-M2-06 writes are specified but not built. |
| R-029 | Design patterns are applied for their own sake beyond genuine need, adding complexity without measurable benefit. | Team | Medium | Open – carried forward | Not evidenced | Judgement for the reflection; no measurement. |
| R-030 | Design diagrams (state/interaction) drift out of consistency with the architecture diagrams, confusing traceability at the defence. | Team | Medium | Open – carried forward | Not evidenced | Same as R-012. |
| R-031 | The authentication mechanism selected in §5.5 stores credentials insecurely (e.g. weak or missing hashing). | Michael | High | Closed – not realised | Not evidenced | Not applicable in practice: no credential storage was built. Becomes live when sign-in is built. |
| R-032 | Role/permission checks exist only in the UI, not enforced server-side, allowing direct API calls to bypass restrictions (violates NFR-001). | Bianca | High | Mitigated – residual risk | Effective | Checks are server-side in the application service; the UI is a landing page only. |
| R-033 | HTTPS/TLS is not correctly configured on the chosen free-tier host, leaving NFR-006 unmet. | Michael | High | Open – carried forward | Not evidenced | Cookie is Secure=Always, but HTTPS was never demonstrated; harness uses loopback HTTP. NFR-006 unmet. |
| R-034 | Verbose error messages or stack traces are exposed to end users, violating NFR-008. | Michael / Cameron | Medium | Mitigated – residual risk | Effective | H12 and H13: store failure returns a generic 500 with no marker text and no caching. |
| R-035 | Secrets required by the chosen stack (DB connection strings, API keys) are committed to the public repository. | Michael | High | Mitigated – residual risk | Effective | Same scan as R-005. |
| R-036 | Insufficient input validation at the API boundary allows malformed or malicious input to reach the data layer. | Cameron / Michael | High | Open – carried forward | Partly effective | Only UUID validation exists. Writer rejects blank input but length limits rely on database errors (the rollback test used an oversize note). No application-level validation for writes. |
| R-037 | The deployment platform chosen in §5.8 is incompatible with the persistence technology chosen in §5.4/§5.5. | Michael | High | Not exercised – carried forward | Partly effective | CI runs the app tests against PostgreSQL 17 with Npgsql, so the stack works together in Actions. The hosting platform was never chosen or tested. |
| R-038 | Local development environments differ meaningfully between team members, causing integration failures ("works on my machine"). | Cameron | Medium | Realised | Effective | PED records that an older system installation had mismatched runtimes and could build but not run. global.json plus the Ubuntu CI runner removed the difference. |
| R-039 | No separation exists between the development instance and shared demo data, risking accidental data loss before a presentation. | Michael | Medium | Open – carried forward | Not evidenced | The app refuses to start outside Development and uses synthetic data; no separate demo instance. |
| R-040 | No rollback plan exists for a bad deployment heading into M3, risking an unrecoverable state near a deadline (extends M1 Forward Engineering Consideration #7). | Michael | Medium | Open – carried forward | Not evidenced | No rollback procedure was tested; three migrations exist (M3-R03). |
| R-041 | The hosting platform's free-tier sleep/scale-to-zero behaviour is mistaken for application failure during a live milestone defence. | Cameron | Low | Not exercised – carried forward | Not evidenced | No hosted instance. |
| R-042 | Combined free-tier limits across hosting, database and any third-party service are exceeded before the project ends. | Michael | Medium | Not exercised – carried forward | Not evidenced | No hosted instance. |
| R-043 | Realistic post-pilot operational cost is not credibly estimated, weakening the final cost review required by the Master Project Brief §18. | Michael | Low | Open – carried forward | Not evidenced | Depends on Michael's pricing. See cost evaluation. |
| R-044 | A third-party service used for testing/CI unexpectedly moves from a free to a paid model mid-project. | Cameron | Low | Mitigated – residual risk | Partly effective | Actions run 38214195229 passed on the persistence branch; a Node.js deprecation warning was recorded and not blocking. |
| R-045 | Architecture/technology decisions are formally baselined (§6) before any implementation evidence confirms they actually work. | Team | Medium | Realised | Partly effective | ADR-M2-02 stayed 'Planned' until M4 and the write path was never integrated, so a baselined decision went unverified for weeks. |
| M3-R01 | Persistence not integrated with transitions and authorisation | Michael | – | Open – carried forward (reduced) | Partly effective | Service and rules now exist and are tested alone. No application service joins authorise → transition → write. Still open. |
| M3-R02 | Concurrent operations on the same request | Michael | – | Mitigated – residual risk | Partly effective | Version token and stale-update rejection tested (DB checks). No user-facing conflict handling and no concurrent-assignment test. |
| M3-R03 | Migrations behave differently in staging | Michael | – | Not exercised – carried forward | Not evidenced | No staging database was used. |
| M3-R04 | Database credentials exposed | Michael | – | Mitigated – residual risk | Effective | Same scan as R-005. |
| M3-R05 | Performance and recovery unverified | Michael | – | Open – carried forward | Not evidenced | No performance, backup or restore evidence. |

## Technical debt (continues TD-M3-01 to TD-M3-04)

| ID | Outstanding work | Why it exists | Consequence if left | Owner | Priority | Final status |
| --- | --- | --- | --- | --- | --- | --- |
| TD-M3-01 | Join authorise → transition → persist in one application service | Components were built separately | FR-009, FR-010, FR-012 cannot be demonstrated end to end; R-011 stays open | Cameron with Michael and Bianca | High | **Open.** Lifecycle service and ownership rule now exist and are tested; nothing calls them yet |
| TD-M3-02 | History covers more than status changes | Schema built for status only | FR-015 stays partial | Michael | High | Open |
| TD-M3-03 | Duplicate-submission protection | No request-creation path exists | NFR-003 AC-2 and FR-001 unmet | Michael / Cameron | High | Open |
| TD-M3-04 | Staging, migration and restore verification | No hosted environment | NFR-006, NFR-007 unmet; release decision cannot be evidence-based | Michael | High | Open |
| TD-M4-01 | `EfRequestStatusWriter` takes raw status strings and is not registered in `Composition.cs`. It should accept `ValidatedStatusChange` | Written before the service existed | Anyone can persist an illegal status by calling it; R-011 cannot close | Michael | High | Open. Guard: check AR01 fails if new code assigns a status |
| TD-M4-02 | No owner, due-date or priority columns on `ServiceRequestEntity` | M3 scoped persistence to status and notes | `OwnershipRule` and the FR-013 calculator have no real data; FR-009, FR-013, FR-017, FR-018 cannot be demonstrated on stored data | Michael | High | Open |
| TD-M4-03 | `RequestNoteEntity` has no author or timestamp | Notes modelled for visibility only | AC-FR-011-1 (author and time) and AC-FR-005-1 (feedback date) cannot be met | Michael | High | Open |
| TD-M4-04 | Target framework `net8.0` leaves support on 10 Nov 2026 | Chosen as an M2 compatibility spike; never revisited | No security patches after that date for any real use | Team | Medium | Open. Upgrade to a supported LTS is the first maintenance task |
| TD-M4-05 | Writer demands non-blank feedback for every transition; the service requires a reason only for Resolved and Rejected (matches FR-005 and AC-FR-012-1) | Two components, two readings | The coordinator must supply a default message for other transitions or the writer throws | Cameron / Michael | Medium | Open. Agree one rule |
| TD-M4-06 | Status values are string literals in the writer, DbContext defaults and the lifecycle code; the column has no CHECK constraint | Strings were used to move fast | A typo is accepted by the database | Michael | Medium | Open |
| TD-M4-07 | Category is a free-text string with no reference table | FR-002 never built | Drift and invalid categories (R-019) | Michael | Medium | Open |
| TD-M4-08 | Harness is a custom executable that stops at the first failure; AR01 uses a text scan | Chosen in ADR-M2-07 to avoid a framework dependency | Failures are reported one at a time; the scan could miss an unusual assignment style | Bianca | Low | Retained, consequence stated |
| TD-M4-09 | README, RTM v2.0 and START_HERE still describe the M2 state (for example "29 checks", "State planned") | Not updated after M3 | Reviewers read a stale picture | Cameron | Medium | Open until PED v4.0 and RTM final |
| TD-M4-10 | `github_workflows_auto-merge-approved-prs.yml` sits in the repository root, so it is inert. If moved into `.github/workflows` it would enable auto-merge after any single approval | Misplaced file | Conflicts with the two-approval rule in the team agreement unless branch protection enforces it | Cameron | Low | Open. Delete or document |

## Evolution view: what a continuing team should do, in order

1. **Join the pieces.** One application service that authorises, calls `IStatusTransitionService`, then calls the writer with a `ValidatedStatusChange` (TD-M3-01, TD-M4-01). Everything else depends on this.
2. **Add the missing columns** (owner, due date, priority, note author and time) with a migration, then connect `OwnershipRule` through a conditional update so two simultaneous claims cannot both win (TD-M4-02, TD-M4-03, R-015).
3. **Build sign-in and request creation.** Without them none of the requester journeys can be run (FR-001, FR-016).
4. **Add lists and the management summary endpoint.** The calculator is ready; the endpoint and the query are not (FR-004, FR-006, FR-013).
5. **Move to a supported .NET version** before any real use (TD-M4-04).
6. **Deploy to staging, test HTTPS, run a restore test and a load test** (NFR-002, NFR-006, NFR-007).

## Known limitations

These are stated plainly so the assessor and a future team do not have to discover them.

- There is no sign-in. The only protected operation can be exercised only with test tickets created inside the verification harness.
- There is no request creation, list, update, assignment or management-summary route. The business rules for transitions, ownership and counts are verified in isolation and are not reachable from the running application.
- The running application refuses to start outside Development (`Program.cs`). It cannot be deployed as built.
- Ownership, due date and priority are not stored, so the ownership rule and the overdue logic have never run on stored data.
- Request notes carry no author or date.
- History records status changes only.
- Concurrent claiming of a request is not verified; only concurrent status updates are (Version token).
- Performance, HTTPS, backup and restore, and usability with real participants have not been measured.
- All data in the application is synthetic.
- The test suite is a custom harness. The 44 lifecycle checks have been run on their own (`docs/evidence/lifecycle-verification.txt`). The combined harness (29 existing + 44 new) and the PostgreSQL suite still need a recorded run on a machine with NuGet access and in CI.
