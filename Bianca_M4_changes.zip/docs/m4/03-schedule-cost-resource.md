# Schedule Variance, Cost and Resource Evaluation

Owner: Bianca Grobler (600537). Status: **DRAFT. Method and workbook ready; the numbers are not.**

The effort logs and Michael's platform pricing were not in the files I received, so this document does not state a single hour, rand or dollar figure. A cost or variance number I could not trace to a record would be exactly the unverifiable claim the team agreed not to write. The workbook `03-schedule-cost-resource.xlsx` holds the formulas; once the inputs go into the yellow cells, the results calculate themselves.

## What is verifiable today

| Fact | Source |
| --- | --- |
| M1 requirements and scope PRs #2 and #3 merged 9 September 2026 | `docs/github-evidence.md` |
| A2 report PR #8 merged 15 September 2026 | `docs/github-evidence.md` |
| A3 submission date 25 September | Assignment 3 cover page |
| M2 architecture and design submitted 30 September 2026 | `README.md`, `START_HERE.md` |
| Persistence code: `InitialCreate` migration timestamped 8 Oct 17:38 UTC; `AddRequestVersion` 12 Oct 06:20 UTC; `AddRequestStatusHistory` 12 Oct 06:31 UTC | `src/CivicConnect.Web/Migrations/` file names |
| Lifecycle rules (ADR-M2-02 State and service) first written 13 October 2026, two weeks after the ADR | this M4 work |
| Schedule constraint: fixed four-milestone period, no extension | PED §2.2.2 |
| Planned project cost: free tiers only (assumption A-03) | PED §2.2 |

## Schedule variance: how to calculate and what the dates already suggest

**Variance (days) = actual finish − planned finish.** Positive means late. Variance % = variance ÷ planned duration. Planned dates come from the team plan, not from memory.

What the repository dates already show, without any planned figures: the three persistence migrations arrived in the last six days before M4, and the status-transition code arrived after that. The critical path ran *persistence → transition rules → integration*, and integration never started. That ordering, not individual effort, is the likely cause of the scope shortfall in `02-success-evaluation-and-consequences.md`. Check this against the effort logs before writing it as a conclusion.

## Effort and resource evaluation: how to calculate

- **Effort variance (h) = actual − planned**, per task and per member.
- **Effort index = planned ÷ actual** for the team. Below 1.0 means the work took more effort than planned.
- **Share of effort** per member shows whether R-006 (uneven contribution) was realised. A share far from one third needs an explanation from the logs; it is not automatically a fault, because the three roles had different workloads by design.

## Cost evaluation: how to calculate

- **Pilot cost to date:** actual spend. If only free tiers were used, state zero and name each free tier and its limit (R-002, R-042).
- **Post-pilot cost (R-043):** for each service, price per month × months of realistic use, in one currency, from Michael's pricing with the source URL and date accessed. The brief requires a credible estimate, so each row needs a source.
- **Cost of the shortfall** is not a monetary figure. State the stakeholder value not delivered instead (see the unmet High-priority criteria).

## What each person must supply

| From | Needed | Where it goes |
| --- | --- | --- |
| Everyone | Effort log: task, milestone, planned hours, actual hours | `Effort` sheet |
| Cameron / team | Planned finish dates for each milestone; actual submission dates from Moodle | `Schedule` sheet |
| Michael | Platform pricing with URL and access date; any actual spend | `Cost` sheet |
| Bianca | Read the three results and write two or three sentences of evidence-based conclusion | PED v4.0 Part III, section 9 |

## Conclusion (to write once inputs exist)

Do not draft this until the numbers are in. A conclusion that states "variance was X days because of Y" needs X from the workbook and Y from the logs.
