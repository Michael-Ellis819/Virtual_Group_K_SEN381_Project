# Defence Preparation (Bianca)

Status: **DRAFT.** This is a map of where the evidence is and what is true, not a script. The assessor asks "show me" and "why", and follows up on rehearsed answers. Know the facts and where to find them; use your own words.

## Your four-minute story

1. **Commitment (M1):** staff move a request through a controlled lifecycle (SR-IN-10); management sees open, overdue, resolved and closed counts (SR-IN-13); a request has one owner (SR-IN-09).
2. **Decisions (M2):** ADR-M2-01 layered application; ADR-M2-02 State pattern with one service that decides status changes.
3. **Delivery:** the rules are built and verified in isolation (44 checks) and persistence is verified separately (25 checks). They were never connected through a route, so the user journeys do not exist yet.
4. **Honest outcome:** proposed scope completion 33.3%; the High-priority gaps are sign-in, request creation, categories, staff list and HTTPS.
5. **Lesson:** build the joining layer first, and make the rule-enforcing service exist before the writer.

## Trace to be able to walk (FR-010)

| Link | Where to show it |
| --- | --- |
| Stakeholder need | PED §1.2 staff; SR-IN-10 |
| Requirement | FR-010 "Controlled status transitions" |
| Acceptance criteria | AC-FR-010-1 (saves new status, previous status, actor, time); AC-FR-010-2 (invalid or unauthorised changes rejected, request unchanged) |
| Decision | ADR-M2-02, PED §5.6 |
| Final implementation | `src/CivicConnect.Web/Lifecycle/RequestState.cs`, `StatusTransitionService.cs`; `Data/EfRequestStatusWriter.cs` |
| Evidence | LC01–LC20, AR01 (`docs/evidence/lifecycle-verification.txt`); DB checks for history and rollback |
| Final status | Partially met, both criteria: rule and persistence are each verified, but not joined |
| Outcome | Reason: persistence arrived last and string-typed (TD-M4-01) |

## Questions you are likely to get, and the true answer

| Question | Truthful answer and where to look |
| --- | --- |
| Which M1 item was hardest, and what affected it? | Joining authorise → transition → persist. Components were built by three people separately; TD-M3-01 |
| Which acceptance criterion is only partly satisfied? | AC-FR-010-1. Writer and rule both work; nothing calls the rule before the writer. Consequence: an illegal status can be persisted by calling the writer directly |
| Why does a working screen not prove a requirement accepted? | Acceptance needs every clause of the criterion shown with evidence. For AC-FR-009-2 an ineligible owner is rejected (OW02–OW04) but simultaneous claims were never tested |
| Which requirement has the strongest and weakest evidence? | Strongest: NFR-001 access control (S, H and DB checks). Weakest: anything needing a deployment, such as NFR-006 and NFR-007, which have none |
| What is your scope completion and how was it calculated? | 18.0 ÷ 54 = 33.3% (7 met, 22 partial, 25 not met). Table in `02-success-evaluation-and-consequences.md` Part C. **Do not quote it until the team has confirmed it** |
| Which critical requirement is incomplete? | FR-001 submit a request, FR-002 categories, FR-006-1 staff list, FR-016-1 sign-in, NFR-006 HTTPS. No approved change covers them; the honest reason is capacity and ordering |
| Deployment state? | No deployment. The app refuses to start outside Development. Staging no-go or development-only, with blockers listed in `02-…` Part A. **Team decision pending** |
| Which earlier decision helped most? | ADR-M2-01: business logic compiles and tests with no EF Core reference (R-009) |
| Which created difficulty? | Planning State at M2 but building it at M4, so persistence was written without it |
| Would you keep State? | Keep the single service and the validated-change type. The State objects add little beyond a transition table. Say this only if you agree after reading the code |
| What technical debt remains? | TD-M4-01 to -10 in `01-risk-register-debt-limitations.md`. The costliest: writer takes strings; no owner or due-date columns |
| If real users used it tomorrow? | Nobody could sign in; no HTTPS evidence; no restore proof; .NET 8 leaves support 10 Nov 2026 |
| What do you know works? | Read-path access control, rollback on failed writes, stale-update rejection, all 36 status pairs, overdue and open rules |
| What remains uncertain? | Concurrent claiming, performance, recovery, real usability |
| How did PED v3.0 become v4.0 without losing history? | v4.0 keeps Parts I–II and the v3.0 M3 sections unchanged and adds Part III |
| What did you personally do? | ADR-M2-01 and 02; the Lifecycle code; the 44 checks; risk, debt and limitations; success evaluation. Be exact about what the AI wrote and what you verified (see the AI register entry 8) |

## Unseen-change questions: where to look first

- **New feature request:** RTM row for the requirement, PED change-control section, affected ADRs. For "reopen a closed request": it is excluded by ADR-M2-02; changing it means editing `ClosedState.AllowedNext`, LC05, LC06, the RTM and the ADR.
- **A critical test fails live:** read the check ID, find the rule file, check whether data (status string, case) or the rule changed. Strings are case-sensitive on purpose (LC09).
- **A limitation becomes mandatory** (say, concurrent claiming): `OwnershipRule`, the writer, the Version token, a migration for the owner column, a conditional update, an integration test with two contexts as in the existing DB concurrency test.
- **Another team inherits it:** README (update first; it is stale), `01-…` debt and evolution view, `docs/decisions`, RTM, the three test suites.

## Before the defence: tasks that only you can do

- Run the full harness and keep the real output.
- Fill the BL column in the mapping file.
- Read `Lifecycle/*.cs` until you can explain each line.
- Confirm or change each scope status.
- Agree the deployment wording with the team.
