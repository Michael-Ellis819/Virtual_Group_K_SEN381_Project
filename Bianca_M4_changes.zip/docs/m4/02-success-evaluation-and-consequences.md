# Final Success Evaluation and Decision Consequence Reflection

Owner: Bianca Grobler (600537). Status: **DRAFT for Bianca and the team to confirm**.
Baseline: repository snapshot supplied plus the M4 lifecycle code. **Final commit hash: [NEEDS: team to insert].**

> **Two things to align before this goes into PED v4.0.**
> 1. The nine row labels in Part A are *working labels*. The Master Project Brief §21 was not in the files I received. Replace each label with §21's wording; the evidence and limitation in each row stay valid.
> 2. Part B needs three to four lines each from Michael and Cameron about the actual outcome of their decisions. Their rows hold only what the repository itself proves, plus a marked gap.

## Part A. Final success evaluation across nine dimensions

Each row gives the evidence, a verdict, and one limitation. "Not evaluated" means no evidence exists. It does not mean the dimension failed.

| # | Dimension (working label) | Evidence in the repository | Verdict | Honest limitation |
| --- | --- | --- | --- | --- |
| 1 | Functional completeness | Proposed Scope Completion 33.3% (18.0 of 54; 7 met, 22 partial, 25 not met). Table in Part C | **Not met.** Below the 80% target | Partial credit is given where a rule is verified in isolation but not reachable through the product. 8 High-priority criteria are wholly unmet, including sign-in (AC-FR-016-1) and request creation (FR-001) |
| 2 | Correctness of business rules | 44 lifecycle checks: all 36 status pairs, ownership eligibility, hand-worked summary dataset. Each rule family was confirmed to fail when deliberately broken | **Met for the rules themselves** | Rules are not called by any route. Owner and due date are not stored, so ownership and overdue logic have never run on stored data |
| 3 | Security and access control | Central deny-by-default policy; 29 harness checks (S01–S15, H01–H14); DB access checks; no real secrets found in the repository | **Partly met** | Covers one read route. No sign-in, no write authorisation, no HTTPS evidence, no dependency scan |
| 4 | Data integrity and reliability | PostgreSQL persistence; status, history and feedback saved in one transaction; rollback verified; stale-update rejection via Version token; 25 DB checks; passing CI run on the persistence branch | **Partly met** | Verified for status changes only. No duplicate-submission protection, no concurrent-claim test, no restore test |
| 5 | Performance | None | **Not evaluated** | NFR-002 needs 10 concurrent users for 10 minutes. Never run |
| 6 | Usability and accessibility | None. The only view is a landing page | **Not evaluated** | NFR-004 and NFR-005 need a submission screen and participants. [NEEDS: results of any walkthrough actually held, see 04-validation-acceptance-defects.md] |
| 7 | Maintainability and testability | Layered structure; the lifecycle namespace compiles with no EF Core or ASP.NET references; three test suites (29 + 44 + 25 checks); CI workflow; pinned package versions | **Mostly met** | Custom harness stops at the first failure. `net8.0` leaves support on 10 Nov 2026. README, RTM v2.0 and START_HERE still describe M2 |
| 8 | Deployment and operability | CI builds and runs tests against PostgreSQL 17. App refuses to start outside Development | **Not met** | No staging or production instance, no rollback or restore evidence. See go-live position below |
| 9 | Process, schedule and cost | Two-reviewer pull-request template; PR and review history recorded in `docs/github-evidence.md`; unchanged requirement baseline (27 requirements, 54 criteria) | **Partly evidenced** | Effort logs and Michael's pricing are not in the repository, so schedule variance and cost cannot yet be stated. See `03-schedule-cost-resource.md` |

### Overall conclusion (proposed wording)

CivicConnect delivered a sound, well-tested foundation for a small part of what it committed to: protected reads, transactional status persistence and independently testable business rules. It did not deliver the end-to-end product. The strongest evidence is that the controls built are verified and the weaknesses are recorded openly. The weakest is that the parts connecting those controls into user journeys were never joined. The team should present that gap itself rather than let the assessor find it.

### Final deployment position (proposed; the team must decide)

The brief allows a defended no-go in staging. The evidence supports one, with specific blockers:

| Blocker | Requirement or risk | Consequence of releasing | What must happen first |
| --- | --- | --- | --- |
| No sign-in or user store | FR-016, AC-FR-016-1; R-031 | Nobody can use the product; access control rests on test tickets only | Build sign-in with hashed credentials |
| No HTTPS evidence | NFR-006; R-033 | Credentials and request data would travel unprotected if hosted over HTTP | Host with a valid certificate and test redirect |
| No restore test | NFR-007; R-018 | Data loss with no proven recovery | Run and record a restore |
| App refuses to start outside Development | `Program.cs` | It cannot run in production as built | Remove the guard only after the three items above |
| .NET 8 leaves support 10 Nov 2026 | R-020; TD-M4-04 | No security patches | Move to a supported LTS |

**Weakness to be ready for:** the brief says staying in staging "because the team did not plan, integrate or complete the work is not automatically a valid engineering precaution". The honest answer is that some of these gaps are unfinished work. What makes the no-go defensible is that releasing a product with no authentication would put requester data at risk and deliver no usable value, and the guard in `Program.cs` was a deliberate control. No staging environment exists either, so "remained in staging" must be worded as "remained in development with CI-only verification". [NEEDS: team decision on wording.]

## Part B. Decision consequence reflection (six decisions)

For each decision: what was decided, what actually happened (only what evidence shows), the consequence, and whether to retain. Rows for decisions owned by others contain a marked gap.

### ADR-M2-01: Layered single application

- **Decided:** presentation, application, business logic and data access in one deployable unit (PED §5.3).
- **Outcome shown by the repository:** the swap from `DevelopmentRequestReader` to `EfRequestReader` behind `IRequestReader` needed a one-line change in `Composition.cs`, and the harness replaces the reader with a fault-injecting one. The lifecycle namespace compiles and tests with no framework packages.
- **Cost seen:** layers gave the right places but not the wiring. `EfRequestStatusWriter` is a concrete class with no interface, takes strings and is not registered, so the write path never joined the layers (TD-M4-01, R-008).
- **Retain?** Yes. The proportionality argument against microservices held: a three-person team never needed more than one unit.

### ADR-M2-02: State pattern for status transitions

- **Decided:** six State objects and a single `StatusTransitionService`.
- **Outcome:** implemented in M4, about two weeks after the ADR. Six small classes plus the service; 44 checks, including every one of the 36 status pairs.
- **What actually produced the value:** the single decision point and `ValidatedStatusChange` (only the service can create one), not the State objects. The states add no behaviour beyond their next-state list, "open" flag and "needs a reason" flag. A transition table would have given the same legality in far less code.
- **What the delay cost:** persistence was built before the service existed, so the writer accepts raw strings and any caller can bypass legality. R-011 is reduced, not closed.
- **Retain?** [Bianca to decide.] Draft position: keep the single service and the validated-change type; accept that State objects were more structure than six statuses needed.

### ADR-M2-03 and ADR-M2-04: PostgreSQL persistence and the C# / ASP.NET Core / EF Core stack (Michael)

- **Verifiable from the repository:** EF Core and Npgsql 8.0.11; three migrations; optimistic concurrency, history table and transactional write; 25 DB checks; CI run against PostgreSQL 17 passed.
- **Verifiable gaps:** schema has no owner, due-date or priority columns; notes have no author or date; history covers status only.
- **[NEEDS Michael: three to four lines of actual outcome, including anything he would change.]**

### ADR-M2-05: Central authorisation (Cameron)

- **Verifiable from the repository:** one policy, one service re-check, 29 checks; `IRequestAccessPolicy` exposes only `EvaluateRead`. There is no write-permission method yet, so no authorisation exists for assignment, status change or closing.
- **[NEEDS Cameron: three to four lines of actual outcome.]**

### ADR-M2-07: Repeatable checks and reviewed integration (Cameron)

- **Verifiable from the repository:** adding 44 checks needed one new file and one call in `Program.cs`, and CI picks them up with no workflow change. The harness stops at the first failure. At M2 no remote run existed; a passing Actions run exists for the persistence branch.
- **[NEEDS Cameron: three to four lines of actual outcome.]**

### Choosing technology before building it

- **Decided:** ADR-M2-04 fixed the stack on 30 September with exact versions "pending"; `net8.0` was labelled a compatibility spike.
- **Outcome:** the stack was right: M3 kept PostgreSQL and EF Core and nothing was swapped. The cost was the version. `net8.0` was never revisited and leaves support on 10 November 2026, (R-020, R-045).
- **Retain?** Retain the stack. Next time, pin the framework version as a decision with a review date, not as a spike.

### Paste-ready "Later consequence" text for ADR-M2-01 and ADR-M2-02

**ADR-M2-01 Later consequence:** "Observed at M4: the data-access boundary worked for reads and for business logic, which compiles and tests with no persistence dependency. The write path did not join the layers: the persistence writer is concrete, string-typed and not registered. Decision retained; the missing application service for writes is recorded as TD-M3-01 and TD-M4-01."

**ADR-M2-02 Later consequence:** "Implemented at M4 as six State classes behind a single StatusTransitionService, with 44 passing checks including all 36 status pairs. The value came from having one decision point and a validated-change type that only the service can create. The State objects themselves add little beyond a transition table. Persistence was built before the service existed, so legality is not yet enforced at the writer (TD-M4-01); R-011 is reduced, not closed."

## Part C. Scope Completion working (proposed)

Rule used (stated so it can be challenged): **Met = 1.0** when every clause of the criterion is demonstrated by automated evidence in the final build. **Partially met = 0.5** when at least one clause is demonstrated. **Not met = 0.0** otherwise. No approved changes exist, so the denominator is all 54 criteria (27 requirements × 2).

**Scope Completion % = 18.0 ÷ 54 × 100 = 33.3%.**

By priority: High 15.0 of 32 (46.9%); Medium 3.0 of 22 (13.6%).

Where the evidence is a rule verified in isolation, that is stated, because the assessor may reasonably mark those lower. If the team reads "Partially met" strictly as "works through the product", the figure falls to 13.0% (Met rows only).

| AC | Priority | Status | Value | Evidence |
| --- | --- | --- | --- | --- |
| AC-FR-001-1 | High | Not met | 0.0 | No creation route or service. Entity has a unique ReferenceNumber index only. |
| AC-FR-001-2 | High | Not met | 0.0 | No submission validation. |
| AC-FR-002-1 | High | Not met | 0.0 | CategoryId is free text; no category list. |
| AC-FR-002-2 | High | Not met | 0.0 | No category validation. |
| AC-FR-003-1 | High | Partially met | 0.5 | Status is persisted and readable (S01, H04, DB checks). No authorised update route exists, so 'after an authorised update' cannot be shown through the product. |
| AC-FR-003-2 | High | Met | 1.0 | S03, H07 and the DB check 'other requester is denied' pass. Covers the one existing endpoint. |
| AC-FR-004-1 | Medium | Not met | 0.0 | No list route. |
| AC-FR-004-2 | Medium | Not met | 0.0 | No list route. |
| AC-FR-005-1 | Medium | Partially met | 0.5 | Feedback is stored with the status change (DB checks) and the service requires a reason for Resolved and Rejected (LC11, LC12). Notes have no date and nothing triggers feedback in the product. |
| AC-FR-005-2 | Medium | Met | 1.0 | Requester-visible notes persist and are returned; internal notes are excluded (S02, H05, DB checks). |
| AC-FR-006-1 | High | Not met | 0.0 | No staff list route. |
| AC-FR-006-2 | High | Met | 1.0 | S05, H09 and the DB check for another category pass. |
| AC-FR-007-1 | Medium | Not met | 0.0 | No search or filter. |
| AC-FR-007-2 | Medium | Not met | 0.0 | No sorting or filtering. |
| AC-FR-008-1 | High | Partially met | 0.5 | DTO returns reference, category, description, location, status, update time and notes. It omits requester, priority, owner and due date. |
| AC-FR-008-2 | High | Partially met | 0.5 | Unauthorised access is denied (S05, S06, H09). Missing owner and due date are not shown because the fields do not exist. |
| AC-FR-009-1 | High | Partially met | 0.5 | OwnershipRule decides one eligible owner (OW01–OW10). Nothing records owner, actor or time. |
| AC-FR-009-2 | High | Partially met | 0.5 | Ineligible owners rejected (OW02–OW04). Simultaneous claims not verified; no owner column. |
| AC-FR-010-1 | High | Partially met | 0.5 | Writer saves previous status, new status, actor and time in a transaction (DB checks); service approves legal changes (LC01, LC02). The two are not connected. |
| AC-FR-010-2 | High | Partially met | 0.5 | Invalid transitions are rejected with no change object (LC01, LC03–LC08). Unauthorised-user rejection is not integrated. |
| AC-FR-011-1 | High | Partially met | 0.5 | Notes are saved (DB checks); blank rejection and author/time are missing. |
| AC-FR-011-2 | High | Partially met | 0.5 | Visible and internal notes are separated (DB checks, H08). Corrections and the requester update path are not built. |
| AC-FR-012-1 | High | Partially met | 0.5 | Reason required to resolve (LC11); actor and time are in the history table. No route. |
| AC-FR-012-2 | High | Partially met | 0.5 | Only Resolved → Closed is legal (LC01, LC13). Authorisation for closing is not integrated. |
| AC-FR-013-1 | Medium | Partially met | 0.5 | Calculator matches a hand-worked dataset (SM01–SM03). No stored due dates and no management endpoint. |
| AC-FR-013-2 | Medium | Partially met | 0.5 | Zero counts and refresh behaviour shown on the calculator (SM07, SM09). No endpoint, so requester denial is not testable. |
| AC-FR-014-1 | Medium | Not met | 0.0 | Not built. |
| AC-FR-014-2 | Medium | Not met | 0.0 | Not built. |
| AC-FR-015-1 | High | Partially met | 0.5 | Status changes only. |
| AC-FR-015-2 | High | Partially met | 0.5 | History persists in PostgreSQL with timestamps. Protection from silent change is not established. |
| AC-FR-016-1 | High | Not met | 0.0 | No sign-in or user store. |
| AC-FR-016-2 | High | Met | 1.0 | H02 (signed out gets 401) and H11 (no elevation by query) pass for the one protected route. |
| AC-FR-017-1 | Medium | Not met | 0.0 | No priority field. |
| AC-FR-017-2 | Medium | Not met | 0.0 | No priority field. |
| AC-FR-018-1 | Medium | Not met | 0.0 | No due date field. |
| AC-FR-018-2 | Medium | Partially met | 0.5 | Overdue rule verified on the calculator (SM04–SM06). No stored due dates or display. |
| AC-NFR-001-1 | High | Met | 1.0 | S03–S12, H03, H07, H09, H11 and DB access checks: no unauthorised disclosure on the implemented surface. No write route to test. |
| AC-NFR-001-2 | High | Met | 1.0 | Ownership and category boundaries enforced while authorised reads succeed (S01, S04, H08). |
| AC-NFR-002-1 | Medium | Not met | 0.0 | No load test. |
| AC-NFR-002-2 | Medium | Not met | 0.0 | No measurement. |
| AC-NFR-003-1 | High | Partially met | 0.5 | Rollback verified for a status change (DB checks). Submission and assignment do not exist. |
| AC-NFR-003-2 | High | Partially met | 0.5 | Records persist in PostgreSQL. Duplicate-submission protection absent (TD-M3-03). |
| AC-NFR-004-1 | Medium | Not met | 0.0 | No participants tested; no submission screen. |
| AC-NFR-004-2 | Medium | Not met | 0.0 | No participants tested. |
| AC-NFR-005-1 | Medium | Not met | 0.0 | Landing page only; not assessed. |
| AC-NFR-005-2 | Medium | Not met | 0.0 | Not assessed. |
| AC-NFR-006-1 | High | Not met | 0.0 | No HTTPS deployment. |
| AC-NFR-006-2 | High | Not met | 0.0 | No HTTPS deployment. |
| AC-NFR-007-1 | Medium | Not met | 0.0 | No restore test. |
| AC-NFR-007-2 | Medium | Not met | 0.0 | No restore test. |
| AC-NFR-008-1 | High | Partially met | 0.5 | H12 shows no leak in a user-facing error. Logs were not tested. |
| AC-NFR-008-2 | High | Partially met | 0.5 | Errors expose no stack trace (H12) but are generic and do not name the failed action. |
| AC-NFR-009-1 | High | Partially met | 0.5 | Access, assignment, status and reporting rules run on test inputs (S, LC, OW, SM). There is no submission rule. |
| AC-NFR-009-2 | High | Met | 1.0 | Repeatable checks (LC19); invalid behaviour is detected (LC01 and AR01 were each confirmed to fail when a rule was deliberately broken). |

**Critical or High-priority criteria with no delivery**, each needing an explicit justification: AC-FR-001-1 and AC-FR-001-2 (submit a request), AC-FR-002-1 and AC-FR-002-2 (controlled categories), AC-FR-006-1 (staff list), AC-FR-016-1 (sign-in), AC-NFR-006-1 and AC-NFR-006-2 (HTTPS). [NEEDS: team to supply justification for each; no approved change covers them.]
