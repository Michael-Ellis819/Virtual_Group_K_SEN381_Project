# Stakeholder Validation, Usability, Manual Acceptance and Defect Register

Owner: Bianca Grobler (600537). Status: **DRAFT. Protocols and the defect register are ready. No validation session has been run, and none can be run on the current build for the reasons below.**

**Rule for this document: a result goes in only after a real session or run happened.** Every "Result" cell is blank or says "Not run". Nothing here describes a participant, a time or an observation that did not occur.

## Why the walkthroughs cannot be run on this build

The snapshot has no sign-in, no request-submission screen, no list screen and no management screen. The only view is a landing page, and the only protected route is `GET /requests/{id}`, reachable with a test ticket created inside the verification harness. A stakeholder cannot walk through a journey the product does not offer. The honest outcomes are:

- **Walkthrough on the real product:** not possible; the journeys do not exist.
- **Walkthrough of the verified rules:** possible. A stakeholder can watch the checks run and see the rule outcomes, which is evidence of rule correctness, not of usability.
- **Usability test of NFR-004:** not possible until a submission and status screen exist.

If the team builds sign-in and submission before the deadline, the protocols below are ready.

## 1. Stakeholder validation walkthroughs

### Requester (Stakeholder need: submit a request and see its status)

| Step | Journey | Criterion | Possible on this build? | Result |
| --- | --- | --- | --- | --- |
| R1 | Sign in | AC-FR-016-1 | No (no sign-in) | Not run |
| R2 | Submit a request with category, description, location | AC-FR-001-1, AC-FR-001-2 | No | Not run |
| R3 | See status and update date of own request | AC-FR-003-1 | Partly: read route exists; no way to create or update through the product | Not run |
| R4 | Try another requester's reference | AC-FR-003-2 | Yes, with a test ticket (harness S03, H07) | Verified by automated check, not by a participant |
| R5 | See feedback without internal notes | AC-FR-005-2 | Yes, with a test ticket (S02, H05) | Verified by automated check |

### Staff (Stakeholder need: take ownership and move a request through the lifecycle)

| Step | Journey | Criterion | Possible on this build? | Result |
| --- | --- | --- | --- | --- |
| S1 | See permitted requests | AC-FR-006-1 | No (no list route) | Not run |
| S2 | Open a request outside own category | AC-FR-006-2 | Yes (S05, H09) | Verified by automated check |
| S3 | Accept ownership; a second person tries the same | AC-FR-009-1, -2 | Rule only (OW01, OW05). No route, no stored owner | Rule verified; journey not run |
| S4 | Move New → Assigned → In Progress → Resolved → Closed | AC-FR-010-1, AC-FR-012-1 | Rule only (LC01, LC02, LC11, LC13) | Rule verified; journey not run |
| S5 | Attempt an illegal move (for example New → Closed) | AC-FR-010-2 | Rule only (LC03) | Rule verified; journey not run |

### Management (Stakeholder need: see open, overdue, resolved and closed counts)

| Step | Journey | Criterion | Possible on this build? | Result |
| --- | --- | --- | --- | --- |
| M1 | View counts | AC-FR-013-1 | Calculator only (SM01). No endpoint or stored due dates | Rule verified; journey not run |
| M2 | Refresh after a change; see zeros | AC-FR-013-2 | Calculator only (SM07, SM09) | Rule verified; journey not run |
| M3 | Requester tries to read totals | AC-FR-013-2 | No endpoint exists | Not run |

Record for any session that is actually held: date, participant role (not name), tasks attempted, whether each succeeded without help, time taken, errors, comments, and who ran it.

## 2. Usability results for NFR-004 (protocol)

NFR-004 needs at least four of five representative participants to submit a valid request and find its status within five minutes without coaching (AC-NFR-004-1), using the same task for all (AC-NFR-004-2).

| Participant | Role/background | Submitted valid request? | Found status? | Time (min) | Errors | Coaching given? |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | | | | | | |
| 2 | | | | | | |
| 3 | | | | | | |
| 4 | | | | | | |
| 5 | | | | | | |

**Result: Not run.** Requires a submission and status screen and sign-in. **Final status for NFR-004: Not met (no evidence).** Stating that plainly protects marks better than inventing a pass.

## 3. Manual acceptance checks on the deployed product

**There is no deployed product.** The application refuses to start outside Development. The checks that can be done on the local development build are below. Run them yourself and record the result; I could not run the web application here because package restore was blocked.

| # | Check | How | Expected | Result |
| --- | --- | --- | --- | --- |
| 1 | App starts | Set `ConnectionStrings__CivicConnect` to any valid string, `ASPNETCORE_ENVIRONMENT=Development`, run the web project (see defect DEF-M4-01) | Starts | |
| 2 | Landing page | Open `/` | Page shows "CivicConnect" | |
| 3 | Signed-out protection | `GET /requests/11111111-1111-1111-1111-111111111111` with no cookie | 401, no redirect | |
| 4 | Malformed ID | Request `/requests/not-a-uuid` with a valid ticket | 400 | |
| 5 | Full harness | `dotnet run --project tests/CivicConnect.Verification` | `RESULT 73 checks passed` | |
| 6 | Database suite | Run `tests/CivicConnect.DatabaseTests` against a test PostgreSQL | "All database integration checks passed." | |
| 7 | CI | Push or open a PR | Workflow green | |

Checks 3 and 4 are already covered by H02 and H10. The manual check is for the demonstration.

## 4. Defect register (M3 → final)

The brief says the **existing** Defect Register is finalised, not recreated. No defect register file exists in the repository; defects are meant to be GitHub Issues (PED §6). **[NEEDS: export the open and closed defect Issues from GitHub and use them as the register.]** The entries below are defects I found by reading the code in this snapshot. Each should be raised as an Issue and then listed here under the Issue number. Statuses are based on reading the code, not on a reproduced run, unless stated.

| ID | Defect | Where | Severity | Affects | Owner | Final status |
| --- | --- | --- | --- | --- | --- | --- |
| DEF-M4-01 | README tells users to run the app with no connection string. Startup throws "CivicConnect database connection is not configured" | `Composition.cs` lines 33–35; README "Run the development application" | Medium | Demonstration, onboarding | Cameron | **Open** |
| DEF-M4-02 | README states "no external NuGet package dependencies", "EF Core… not yet added", "29 checks". All three are out of date | README "Prerequisites", "Current implementation" | Medium | Accuracy of evidence | Cameron | **Open** |
| DEF-M4-03 | Writer accepts raw status strings; any caller can persist an illegal status; it is also not registered in DI, so the app cannot reach it | `EfRequestStatusWriter.cs` lines 11–17 and 49; `Composition.cs` | High | FR-010, R-011 | Michael | **Open** (see TD-M4-01) |
| DEF-M4-04 | Writer always saves feedback as requester-visible, so no code path can record an internal note | `EfRequestStatusWriter.cs` line 69 | Medium | AC-FR-011-2 | Michael | **Open** |
| DEF-M4-05 | Notes have no author or timestamp | `RequestNoteEntity.cs` | High | AC-FR-011-1, AC-FR-005-1 | Michael | **Open** (TD-M4-03) |
| DEF-M4-06 | Reader returns notes with no ordering, so note order is not guaranteed between reads | `EfRequestReader.cs` line 33 | Low | Consistency of display | Michael | **Open** |
| DEF-M4-07 | `UpdatedAt` and history `ChangedAt` come from two separate clock reads, so they differ slightly for the same change | `EfRequestStatusWriter.cs` lines 50, 60 | Low | FR-015 elapsed-time accuracy | Michael | **Open** |
| DEF-M4-08 | The database test project does not set `TreatWarningsAsErrors`; the other two projects do | `CivicConnect.DatabaseTests.csproj` | Low | Build consistency | Michael | **Open** |
| DEF-M4-09 | AI usage records disagree: `docs/ai-usage.md` names OpenAI Codex for Cameron; PED §12 names ChatGPT | `docs/ai-usage.md`, PED v3.0 §12 | Medium | Integrity of the AI register | Cameron | **Open** until reconciled |
| DEF-M4-10 | A workflow file in the repository root would auto-merge after one approval if moved into `.github/workflows` | `github_workflows_auto-merge-approved-prs.yml` | Low | Two-approval rule | Cameron | **Open** (delete or document) |

### Important M3 items and their final status (brief §7)

| M3 item | Final status | Evidence |
| --- | --- | --- |
| Persistence not integrated with transitions and authorisation (M3-R01, TD-M3-01) | **Open, reduced.** Rules now exist and are tested; nothing connects them | Lifecycle checks; DEF-M4-03 |
| Concurrent updates (M3-R02) | **Partly resolved.** Stale updates rejected (tested). Conflict message for users not built; concurrent assignment untested | DB checks |
| Migrations in staging (M3-R03) | **Carried transparently.** No staging environment | None |
| Credentials (M3-R04) | **Resolved for the repository.** No real secrets found | Repository scan |
| Performance and recovery (M3-R05) | **Not done.** Limitation | None |
| Failed or conditional quality checks | None recorded in the repository. [NEEDS: confirm none, or add them] | |
| Re-verification of an important fix | Rollback and stale-update behaviour were verified by the DB suite in Michael's CI run (Actions run 38214195229). **A rerun on the final commit is needed** | DB suite output |
