# Pull-request review notes: Michael's persistence and Cameron's read slice and tooling

Reviewer: Bianca Grobler (draft prepared with AI assistance, to be checked and posted by Bianca on the actual pull requests). Findings come from reading the supplied snapshot. I could not restore packages, so nothing here was reproduced by running the web project or database suite. Each item says whether it blocks merge. The brief asks for meaningful reviews, so post these as line comments, not as a summary.

## Michael: PostgreSQL persistence (`feature/m3-data-persistence`)

**Good, and worth saying:** optimistic concurrency token with a version bump in `SaveChanges`; status, history and feedback in one transaction; rollback proven with an oversize note; migrations in order; tests clean up after themselves and fail the process on error; CI uses a throwaway database.

| # | File and line | Comment | Blocks? |
| --- | --- | --- | --- |
| 1 | `EfRequestStatusWriter.cs` 11–17, 49 | Takes raw status strings and writes them. With the new `StatusTransitionService` this should accept `ValidatedStatusChange` so persistence cannot be called with an unchecked status (R-011, TD-M4-01). | **Yes, for the integration PR.** Not for the persistence-only PR |
| 2 | `Composition.cs` | The writer is not registered, so the app cannot reach it. Register it and add an interface so the application layer does not depend on a concrete class (R-008). | No |
| 3 | `EfRequestStatusWriter.cs` 69 | Feedback is always saved as requester-visible. Staff cannot record an internal note through this path (AC-FR-011-2). | No, record as DEF-M4-04 |
| 4 | `RequestNoteEntity.cs` | No author or time. AC-FR-011-1 and AC-FR-005-1 need both. Needs a migration. | No, DEF-M4-05 |
| 5 | `ServiceRequestEntity.cs` | No owner, due-date or priority columns, so FR-009, FR-013, FR-017 and FR-018 cannot run on stored data (TD-M4-02). | No, but it blocks the next stage |
| 6 | `EfRequestStatusWriter.cs` 50, 60 | Two clock reads for one change. Read once and use it for both. | No |
| 7 | `EfRequestReader.cs` 33 | Notes have no `OrderBy`; order is unspecified. | No |
| 8 | `EfRequestStatusWriter.cs` 19–22 | Blank feedback throws for every transition; the lifecycle rule requires a reason only for Resolved and Rejected (TD-M4-05). Agree one rule. | No |
| 9 | `CivicConnectDbContext.cs` | `Status` has a max length but no CHECK constraint, so any string is accepted (TD-M4-06). | No |
| 10 | `CivicConnect.DatabaseTests.csproj` | `TreatWarningsAsErrors` missing, unlike the other two projects. | No |
| 11 | `.github/workflows/verify.yml` 7–9 | Branch list hard-codes `feature/m3-data-persistence`; remove after merge. | No |
| 12 | Tests | No test that two concurrent *claims* produce one owner; the existing concurrency test covers status only (R-015). Add when the owner column exists. | No |

## Cameron: protected read slice, composition, harness and docs

**Good, and worth saying:** deny-by-default policy that fails closed on ambiguous identities; the service rechecks for non-HTTP callers; DTO projection hides internal notes; missing and forbidden both return 404; generic 500 with no leak; harness minting tickets only in tests; honest limitations in the README.

| # | File and line | Comment | Blocks? |
| --- | --- | --- | --- |
| 1 | README "Run the development application" | The command omits `ConnectionStrings__CivicConnect`. `Composition.cs` 33–35 throws at startup without it (DEF-M4-01). | **Yes** for a demonstration build |
| 2 | README prerequisites and status | Still says no NuGet packages, EF Core not added, 29 checks. All stale (DEF-M4-02). | Yes for the final submission |
| 3 | `IRequestAccessPolicy` | Only `EvaluateRead` exists. Assignment, status change and closing have no authorisation method, so AC-FR-010-2 (unauthorised changes) and AC-FR-012-2 cannot be met. Needed before the integration service. | No, but it blocks FR-009, FR-010, FR-012 |
| 4 | `RequestsController` | No write routes yet (H14 checks this deliberately). When added, they must call `IStatusTransitionService`, not re-implement rules (R-027) and use antiforgery as `api-integration.md` says. | No |
| 5 | `Composition.cs` | Cookie `SecurePolicy.Always` is right, but the harness uses HTTP loopback, so HTTPS is still untested (NFR-006). Say so in the README, as it already does. | No |
| 6 | `docs/ai-usage.md` vs PED §12 | Codex vs ChatGPT conflict (DEF-M4-09). | Yes for the final submission |
| 7 | `github_workflows_auto-merge-approved-prs.yml` | Misplaced and would auto-merge after one approval if moved. Delete or document (DEF-M4-10). | No |
| 8 | `docs/design.md` | Shows only the read slice; add the persistence and lifecycle components (R-012). | No |
| 9 | `tests/CivicConnect.Verification/Program.cs` | Stops at the first failed check, so one run reports one failure (TD-M4-08). Acceptable for now. | No |
| 10 | RTM v2.0 | Still shows M2 statuses. Update FR-009, FR-010, FR-012, FR-013 rows to reference `Lifecycle/*.cs` and LC/OW/SM checks, and FR-010's "Planned" to the true status. | Yes for the final RTM |

## Request to both: the outcome lines for the reflection

Michael: three to four lines on what actually happened with ADR-M2-03 and ADR-M2-04, including anything you would change. Cameron: the same for ADR-M2-05 and ADR-M2-07. Only what you can show from the repository or a run.

## Review of Bianca's own PR (for them to do)

Suggested things for Michael and Cameron to check in her pull request: rules are in `Lifecycle/` with no framework reference; `Composition.cs` gains one `using` and three registrations; `Program.cs` gains one hook; AR01 allows exactly one file (the writer) to assign a status, and that allowance is the debt TD-M4-01. Ask them to run the full harness and report the real count.
