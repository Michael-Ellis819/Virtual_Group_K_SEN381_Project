# Part III Milestone 4: final closure

Part III closes the project. Parts I and II and the M3 sections of PED v3.0 are preserved unchanged. Registers and the RTM are the existing controlled artefacts, referenced here and not copied. Items marked **[NEEDS]** are not yet supplied and must be completed or removed before submission.

## 14 Document control: version 4.0

| Version | Date and provenance | Change |
| --- | --- | --- |
| 4.0 Final | October 2026; consolidated from v3.0 by Bianca Grobler with Michael Ellis and Cameron Purdon | Adds Part III: final product and scope, M3 closure, decision consequences, risk, debt and limitations, deployment decision and project conclusion. Earlier parts unchanged |

## 15 Final product and baseline

| Item | Value |
| --- | --- |
| Repository | https://github.com/Michael-Ellis819/Virtual_Group_K_SEN381_Project |
| Final commit, tag or release | **[NEEDS: exact hash of the frozen main]** |
| Product | CivicConnect: protected request read path with central authorisation; PostgreSQL persistence with transactional status history and optimistic concurrency; lifecycle, ownership and activity-summary business rules |
| Test evidence | Verification harness (29 existing + 44 lifecycle checks, **[NEEDS: real combined run]**); PostgreSQL suite (25 checks); CI workflow `verify.yml` |
| Final RTM | `docs/CivicConnect_RTM_v2.0.xlsx` continued to final status **[NEEDS: Cameron's update]** |

## 16 Final scope and delivery reflection

Baseline: 27 requirements and 54 acceptance criteria from M1, unchanged; no approved scope change exists. Scope Completion % = sum of criterion values ÷ 54 × 100, with Met 1.0, Partially met 0.5, Not met 0.0.

**Proposed result: 18.0 ÷ 54 = 33.3%** (7 met, 22 partial, 25 not met). The per-criterion table with evidence is in `docs/m4/02-success-evaluation-and-consequences.md`, Part C. **[NEEDS: team confirmation of each status before this figure is final.]** The target of 80% was not met. Eight High-priority criteria are wholly unmet: AC-FR-001-1 and -2, AC-FR-002-1 and -2, AC-FR-006-1, AC-FR-016-1, AC-NFR-006-1 and -2. **[NEEDS: justification for each.]**

| M1 scope item | Final status | Reason (from project evidence) |
| --- | --- | --- |
| SR-IN-01 Submit a request | NOT IMPLEMENTED | No creation path was built |
| SR-IN-02 Controlled categories | NOT IMPLEMENTED | Category is free text |
| SR-IN-03 View own status | PARTIALLY IMPLEMENTED | Read route and access control work; no sign-in, no update path |
| SR-IN-04 Request history list | NOT IMPLEMENTED | No list route |
| SR-IN-05 Feedback on events | PARTIALLY IMPLEMENTED | Feedback persists and is filtered; no date, no event trigger |
| SR-IN-06 Staff request list | PARTIALLY IMPLEMENTED | Direct access control works; no list |
| SR-IN-07 Search, filter, sort | NOT IMPLEMENTED | Not built |
| SR-IN-08 Full request detail | PARTIALLY IMPLEMENTED | Several fields missing (requester, priority, owner, due date) |
| SR-IN-09 Assign or accept ownership | PARTIALLY IMPLEMENTED | Rule verified; no stored owner, no route |
| SR-IN-10 Controlled status transitions | PARTIALLY IMPLEMENTED | Rule and persistence verified separately; not joined |
| SR-IN-11 Notes and actions | PARTIALLY IMPLEMENTED | Notes stored with visibility; no author or time |
| SR-IN-12 Resolve and close | PARTIALLY IMPLEMENTED | Rule verified; no route or authorisation |
| SR-IN-13 Aggregate activity | PARTIALLY IMPLEMENTED | Calculator verified; no endpoint or stored due dates |
| SR-IN-14 Category/status view | NOT IMPLEMENTED | Not built |
| SR-IN-15 Accountability data | PARTIALLY IMPLEMENTED | Status history only |
| SR-FUT-01 to 06 | STILL DEFERRED | Correctly outside the committed scope; not failures |
| Out of scope items | UNCHANGED | WhatsApp/email integration, payments, native mobile, multi-tenant |

## 17 M3 findings: final status

Defects, risks and debt are in the controlled registers. Summary: the persistence-integration risk (M3-R01) is **reduced, not closed** because the rules now exist and are tested but nothing calls them; concurrency protection is partly resolved; staging, recovery and performance verification were **not done** and are carried as limitations. Full detail: `docs/m4/01-risk-register-debt-limitations.md` (risk register R-001 to R-045 and M3-R01 to R05, debt TD-M3-01 to TD-M4-10) and `docs/m4/04-validation-acceptance-defects.md` (defect register DEF-M4-01 to 10). **[NEEDS: reconcile with GitHub Issues.]**

## 18 Significant decisions and their consequences

ADR-M2-01 and ADR-M2-02 now carry their final consequence text (see `docs/m4/02-…`, Part B). ADR-M2-03/04, 05 and 07 carry verifiable outcomes **[NEEDS: outcome lines from Michael and Cameron]**. Decision register: `docs/decisions/README.md`.

## 19 Known limitations and future work

No sign-in, creation, list, update or management routes; the application refuses to start outside Development; owner, due date and priority are not stored; notes have no author or time; history covers status only; concurrent claiming, performance, HTTPS and recovery are unverified; .NET 8 leaves support on 10 November 2026. Ordered next steps: `docs/m4/01-…`, "Evolution view".

## 20 Final deployment and go-live decision

**[NEEDS: team decision.]** Proposed: not released; development with CI-only verification, justified by the blockers in `docs/m4/02-…`, Part A (no sign-in, no HTTPS evidence, no restore test, a deliberate startup guard). The decision is defensible only if worded as a safety decision and not as a missed deadline.

## 21 Success evaluation

Nine-dimension evaluation with a limitation per row: `docs/m4/02-…`, Part A. **[NEEDS: Master Project Brief §21 labels.]**

## 22 Schedule, cost and resource evaluation

Method and workbook: `docs/m4/03-schedule-cost-resource.md` and `.xlsx`. **[NEEDS: effort logs, planned dates, Michael's pricing, then conclusion.]**

## 23 Validation and acceptance

Walkthrough protocols, NFR-004 protocol and manual checks: `docs/m4/04-…`. No participant session has been run; NFR-004 is Not met for lack of evidence.

## 24 AI Usage Register

Consolidated register: `docs/m4/05-ai-usage-register.md`. Includes one unresolved conflict (Codex vs ChatGPT) to correct before submission.

## 25 Project conclusion

CivicConnect delivered a sound, well-tested foundation for part of what it committed to: protected reads, transactional persistence and independently testable business rules. It did not deliver the end-to-end product, because the pieces were never joined into user journeys and sign-in and submission were not built. The team recorded this openly. The decisions that paid off were the layered structure and central authorisation. The decision that cost most was planning the lifecycle service at M2 but building it after persistence. Next: join authorise, transition and persist; add the missing columns; build sign-in and submission; upgrade .NET; then deploy to staging.

## 26 References

Microsoft (2026), .NET 8 and .NET 9 end of support. https://devblogs.microsoft.com/dotnet/dotnet-8-9-end-of-support/ (accessed 13 October 2026).
