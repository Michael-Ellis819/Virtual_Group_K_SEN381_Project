# AI Usage Register: consolidated across the lifecycle

Owner: Bianca Grobler (600537). Status: **DRAFT.** This continues the existing register (M1 PED section 8, M2 PED section 12, `docs/ai-usage.md`). It is not a new register. Earlier entries are reproduced as recorded; discrepancies are flagged, not silently fixed.

| # | Milestone | Member | Tool | Purpose | Output used? | How verified | Changed or rejected | Source |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | M1 | Michael Ellis | ChatGPT | Find a way to track task ownership with evidence | Yes: use GitHub Issues | Reviewed against project requirements | Other tracking methods not used | PED M1 §8 |
| 2 | M1 | Cameron Purdon | ChatGPT | Understand and break down the work | Yes: small pieces and structure | Compared with online sources and lecture notes | Wordy or irrelevant material rejected | PED M1 §8 |
| 3 | M1 | Bianca Grobler | ChatGPT | Create tables for the risk register | Yes | Reviewed against project requirements | Over-complex tables rejected | PED M1 §8 |
| 4 | M2 | Cameron Purdon | ChatGPT (PED) **or** OpenAI Codex (`docs/ai-usage.md`) **[CONFLICT]** | Requirements review, ADRs, read implementation, 29 checks, PED/RTM consolidation | Yes, after review | Built with zero warnings; 29 checks passed; reviewed by Bianca and Michael | Incorrect or wordy explanations corrected | PED §12; `docs/ai-usage.md` |
| 5 | M2 | Bianca Grobler | ChatGPT | Understand architecture requirements; organise alternatives; draft architecture and design-pattern text; improve wording | Yes, after revision | Compared with M2 brief, requirements, Assignment 2 research, team decisions | Unsupported claims and over-complex alternatives removed | PED §12 |
| 6 | M2 | Michael Ellis | ChatGPT | Understand data, persistence, stack and deployment requirements; organise alternatives; improve wording | Yes, after revision | Compared with M2 brief, requirements, Assignment 2 research | Unsupported implementation claims and unsuitable suggestions removed | PED §12 |
| 7 | M3 | Michael Ellis | ChatGPT | C# and EF Core guidance, PostgreSQL integration, Git troubleshooting, testing approaches, documentation | Yes | Reviewed and tested locally; database checks run; committed through GitHub | Not recorded. Limitation recorded: full integration pending | `docs/ai-usage.md` (12 Oct 2026) |
| 8 | M4 | Bianca Grobler | Claude (Anthropic), Claude Code session, model `claude-sonnet-5-5` | Write the lifecycle code (State classes, `StatusTransitionService`, ownership rule, activity summary); write 44 checks; draft the risk register, success evaluation, defect register, schedule/cost workbook, AI register, defence notes and PR review notes | **[Bianca to complete]** | See "Verification Bianca must complete" below | **[Bianca to complete]** | This session, 13–16 Oct 2026 |

## Entry 8 in the register's own format (Bianca to complete the bracketed parts)

| Field | Description |
| --- | --- |
| Date | 13 October 2026 onward |
| Student | Bianca Grobler, 600537 |
| AI tool | Claude (Anthropic), via a Claude Code session |
| Purpose | M4 business rules, tests, evidence documents and defence preparation |
| How AI was used | Read the repository and PED; wrote `src/CivicConnect.Web/Lifecycle/*.cs`, `tests/CivicConnect.Verification/LifecycleChecks.cs` and a one-line hook in `Program.cs`; drafted the documents in `docs/m4/`; built the schedule/cost workbook |
| What the AI did **not** have | Your BL-01 to BL-11 designs; Master Project Brief §21 and §22; effort logs; Michael's pricing; teammates' outcome lines; the final commit hash; NuGet access (so it could not run the full harness or the web project) |
| Human verification | **[You complete after doing the items below]** |
| Limitations | The 44 checks were run in isolation, outside the web project. The scope-completion statuses are the AI's proposals from reading the repository, not agreed team judgements. No numbers for effort, cost or schedule were produced |
| Final responsibility | Bianca Grobler (600537) |

### Verification Bianca must complete before signing this entry

1. Read every file under `src/CivicConnect.Web/Lifecycle/` and be able to explain each rule without notes.
2. Run the full harness locally and replace `docs/evidence/lifecycle-verification.txt` with the real output (expect 73 checks).
3. Compare the 44 checks with your own BL-01 to BL-11 designs and update `docs/evidence/business-rule-test-mapping.md`.
4. Challenge each of the 54 scope-completion statuses; change any you cannot defend.
5. Check every fact in the documents against the repository. Anything marked **[NEEDS]** is a gap, not a finding.
6. Record what you changed or rejected in the "Changed or rejected" column.

## Reconciliation actions

| Issue | Action | Owner |
| --- | --- | --- |
| Codex vs ChatGPT for Cameron's M2 entry | Cameron states which tool was used; correct whichever record is wrong, and note the correction | Cameron |
| Michael's M3 entry has no "changed or rejected" field | Michael adds it | Michael |
| Register is split across PED sections and `docs/ai-usage.md` | Keep this table as the single index in PED v4.0 and link the sources | Bianca |
| R-007 (AI output unverified) final status | Stays "Mitigated – residual risk" until the conflict above is fixed | Bianca |
