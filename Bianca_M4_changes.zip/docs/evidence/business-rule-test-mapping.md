# Business-rule checks and design-case mapping

The 44 checks in `tests/CivicConnect.Verification/LifecycleChecks.cs` were written from the rules in PED v3.0 (ADR-M2-02, FR-009, FR-010, FR-012, FR-013, FR-018 and the M1 open/overdue rules). **They were not written from Bianca's BL-01 to BL-11 designs, because those designs were not available.** The "BL design" column is left blank for Bianca to fill from her own designs. Any BL case with no matching check needs a new check; any check with no BL case should be kept only if it can be justified.

| Check | What it proves | Requirement / criterion | BL design |
| --- | --- | --- | --- |
| LC01 | Exactly five legal transitions; all 36 pairs checked | FR-010, AC-FR-010-1 | |
| LC02 | Allowed change carries previous status, new status, actor | AC-FR-010-1 | |
| LC03 | Skipping a step rejected, no change object | AC-FR-010-2 | |
| LC04 | Backward move rejected | FR-010 | |
| LC05 | Closed and Rejected are terminal | ADR-M2-02 | |
| LC06 | Reopening rejected | ADR-M2-02 (reopen excluded) | |
| LC07 | Same-status move rejected | FR-010 | |
| LC08 | Rejecting a non-New request rejected | ADR-M2-02 | |
| LC09 | Unknown, blank, null, wrong-case statuses fail closed | FR-010 | |
| LC10 | Missing actor rejected | FR-015 | |
| LC11 | Resolve needs a summary | AC-FR-012-1 | |
| LC12 | Reject needs a reason | AC-FR-005-1 | |
| LC13 | Close needs no reason; legal from Resolved | AC-FR-012-2 | |
| LC14 | Assign without owner rejected | FR-009 | |
| LC15 | Actor and feedback trimmed | FR-010 | |
| LC16 | Illegal pair reported as illegal first | FR-010 | |
| LC17 | Next-status listing | FR-010 | |
| LC18 | Six states; only three are open | M1 open rule | |
| LC19 | Repeatable result | AC-NFR-009-2 | |
| LC20 | Null request throws | robustness | |
| OW01 | Eligible staff can own an unowned New request | AC-FR-009-1 | |
| OW02 | Wrong category rejected | AC-FR-009-2 | |
| OW03 | Inactive staff rejected | AC-FR-009-2 | |
| OW04 | Requester, Management, unknown roles never own | AC-FR-009-2 | |
| OW05 | Second person cannot take an owned request | AC-FR-009-2 | |
| OW06 | Current owner claiming again is a no-op | FR-009 | |
| OW07 | Non-New requests cannot gain an owner | FR-009 | |
| OW08 | Invalid input rejected | FR-009 | |
| OW09 | Category match is exact | FR-009 | |
| OW10 | Several categories allowed | FR-009 | |
| OW11 | Assign decision leads to a legal transition | FR-009 + FR-010 | |
| SM01 | Hand-worked dataset gives expected counts | AC-FR-013-1 | |
| SM02 | Every request accounted for | FR-013 | |
| SM03 | Open = New, Assigned, In Progress | M1 rule | |
| SM04 | No due date is never overdue | M1 rule, AC-FR-018-2 | |
| SM05 | Boundary: due exactly now is not overdue | AC-FR-018-2 | |
| SM06 | Resolved, Closed, Rejected never overdue | AC-FR-018-2 | |
| SM07 | Empty data gives zeros | AC-FR-013-2 | |
| SM08 | Overdue never exceeds open | FR-013 | |
| SM09 | New saved request shows on refresh | AC-FR-013-2 | |
| SM10 | Later clock makes more overdue | FR-018 | |
| SM11 | Unrecognised status rejected | robustness | |
| SM12 | Null list throws | robustness | |
| AR01 | No code outside Lifecycle assigns a status except the persistence writer | R-011 | |

**Mutation check done:** breaking three rules on purpose (allowing Assigned → Rejected, using `<=` for overdue, adding a file that assigns a status) made LC01, SM05 and AR01 fail respectively. The code was then restored and all 44 passed. This was done once, in the AI-assisted session, and is not part of the harness.

**Not covered (needs persistence or a route):** concurrent claiming of one request, authorisation for assignment and closing, owner and due date on stored data.
